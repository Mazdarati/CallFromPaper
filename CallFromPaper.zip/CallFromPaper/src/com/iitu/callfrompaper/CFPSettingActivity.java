package com.iitu.callfrompaper;

import android.os.Bundle;
import android.os.Environment;

public class CFPSettingActivity extends CFPOptionMenuActivity {
	
	protected static String codeUser = "727";
	public static final String lang = "eng";
	protected static final String TAG = "CallFromPaper.java";
	protected static final String PHOTO_TAKEN = "photo_taken";
	public static final String DATA_PATH = Environment
			.getExternalStorageDirectory().toString() + "/CallFromPaper/";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.setting);
	}
}
