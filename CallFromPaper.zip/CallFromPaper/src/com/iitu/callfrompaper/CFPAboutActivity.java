package com.iitu.callfrompaper;

import android.os.Bundle;

public class CFPAboutActivity extends CFPOptionMenuActivity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.about);
	}
}