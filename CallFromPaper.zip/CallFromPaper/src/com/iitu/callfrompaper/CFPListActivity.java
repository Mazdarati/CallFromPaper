package com.iitu.callfrompaper;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import com.googlecode.tesseract.android.TessBaseAPI;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class CFPListActivity extends CFPOptionMenuListActivity {
	
	private ArrayList<String> phoneNumbers = new ArrayList<String>();
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.list);
		String path = CFPSettingActivity.DATA_PATH + "/last_photo.jpg";
		String DATA_PATH = CFPSettingActivity.DATA_PATH;
		String lang  = CFPSettingActivity.lang;
		String TAG  = CFPSettingActivity.TAG;
		BitmapFactory.Options options = new BitmapFactory.Options();
		options.inSampleSize = 4;
		Bitmap bitmap = BitmapFactory.decodeFile(path, options);
		try {
			ExifInterface exif = new ExifInterface(path);
			int exifOrientation = exif.getAttributeInt(
					ExifInterface.TAG_ORIENTATION,
					ExifInterface.ORIENTATION_NORMAL);
			int rotate = 0;
			switch (exifOrientation) {
				case ExifInterface.ORIENTATION_ROTATE_90:
					rotate = 90;
					break;
				case ExifInterface.ORIENTATION_ROTATE_180:
					rotate = 180;
					break;
				case ExifInterface.ORIENTATION_ROTATE_270:
					rotate = 270;
					break;
			}
			if (rotate != 0) {
				// Getting width & height of the given image.
				int w = bitmap.getWidth();
				int h = bitmap.getHeight();
				// Setting pre rotate
				Matrix mtx = new Matrix();
				mtx.preRotate(rotate);
				// Rotating Bitmap
				bitmap = Bitmap.createBitmap(bitmap, 0, 0, w, h, mtx, false);
			}
			// Convert to ARGB_8888, required by tess
			bitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true);
		} catch (IOException e) {
			Log.e(TAG, "Couldn't correct orientation: " + e.toString());
		}
		
		TessBaseAPI baseApi = new TessBaseAPI();
		baseApi.setDebug(true);
		baseApi.init(DATA_PATH, lang);
		baseApi.setImage(bitmap);
		String recognizedText = baseApi.getUTF8Text();
		baseApi.end();

		// You now have the text in recognizedText var, you can do anything with it.
		// We will display a stripped out trimmed alpha-numeric version of it (if lang is eng)
		// so that garbage doesn't make it to the display.
		
		HashMap<String, String[]> map = new HashMap<String, String[]>();
		map.put("Altel(Password, Dalacom)", new String[] {"700","708"});
		map.put("Activ(Kcell)", new String[] {"701","702","775","778"});
		map.put("Beeline(K-Mobile)", new String[] {"705","771","776","777"});
		map.put("Tele2", new String[] {"707","747"});
		map.put("Others", new String[] {"800","801","802","803","804","805","806",
				"807","808","809","881","899"});
		map.put("City", new String[] {"710","711","712","713","714","715","716","717","718",
				"721","722","723","724","725","726","727","728","729"});
		
		recognizedText = recognizedText.replaceAll("[^0-9]+", " ");
		recognizedText = recognizedText.replaceAll(" ", "");

		if ( recognizedText.length() != 0 ) {
			boolean isEnd = false;
			String codeOper, currentPhone; currentPhone = recognizedText;
			do {
				if(currentPhone == "") {
					isEnd = true;
				} else {
					if(currentPhone.startsWith("8")) {
						codeOper = currentPhone.substring(1, 4);
						if( containsValue(map.get("Altel(Password, Dalacom)"),codeOper) ||
								containsValue(map.get("Activ(Kcell)"),codeOper) ||
								containsValue(map.get("Beeline(K-Mobile)"),codeOper) ||
								containsValue(map.get("Tele2"),codeOper) || 
								containsValue(map.get("Others"),codeOper) ||
								containsValue(map.get("City"),codeOper)) {
							if(currentPhone.length() >= 11) {
								phoneNumbers.add(currentPhone.substring(0,11));
								currentPhone = currentPhone.substring(11);
							}
						}
					} else if(currentPhone.startsWith("2")) {
						if(currentPhone.length() >= 7) {
							phoneNumbers.add("8"+CFPSettingActivity.codeUser+currentPhone.substring(0,7));
							currentPhone = currentPhone.substring(7);
						}
					} else {
						currentPhone = "";
					}
				}
			} while(!isEnd);
			showList();
		} else {
			Intent intent = new Intent(this, CFPActivity.class);
	        startActivity(intent);
		}
	}
	@Override
	public void onCreateContextMenu(ContextMenu menu, View v,
	                                ContextMenuInfo menuInfo) {
	    super.onCreateContextMenu(menu, v, menuInfo);
	    MenuInflater inflater = getMenuInflater();
	    inflater.inflate(R.menu.context_menu, menu);
	}
	@Override
	public boolean onContextItemSelected(MenuItem item) {
	    AdapterContextMenuInfo info = (AdapterContextMenuInfo) item.getMenuInfo();
	    switch (item.getItemId()) {
	        case R.id.context_call:
	            callPhone(info.toString());
	            return true;
	        case R.id.context_edit:
	            editPhone(info.id);
	            return true;
	        case R.id.context_delete:
	            deletePhone(info.id);
	            return true;
	        default:
	            return super.onContextItemSelected(item);
	    }
	}
	
	@Override
	protected void onListItemClick(ListView l, View v, int position, long id) {
		String item = (String) getListAdapter().getItem(position);
		//Toast.makeText(this, item + " selected", Toast.LENGTH_LONG).show();
		callPhone(item);
	}
	
	public static boolean containsValue(String[] map, String codeOper) {
	    for (int i = 0; i < map.length ; i++)
	        if (map[i].equals(codeOper))
                return true;
	    return false;
	}
	private void showList() {
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
		        android.R.layout.simple_list_item_1, phoneNumbers);
		setListAdapter(adapter);
	}
	public void callPhone(String recognizedText) {
        String number = "tel:" + recognizedText;
        //Intent callIntent = new Intent(Intent.ACTION_DIAL, Uri.parse(number));
        Intent callIntent = new Intent(Intent.ACTION_CALL, Uri.parse(number)); 
        startActivity(callIntent);
	}
	private void deletePhone(long id) {
		phoneNumbers.remove(id);
	}
	private void editPhone(long id) {
		phoneNumbers.remove(id);
	}
}
