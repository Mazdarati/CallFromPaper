package com.iitu.callfrompaper;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

public class CFPOptionMenuActivity extends Activity {
	 @Override
	 protected void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	  }
	//--------------------------- Option menu ---------------------------
	/**
	 * Override function 'onCreateOptionsMenu' to specify option menu
	 */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
    	MenuInflater inflater = getMenuInflater();
	    inflater.inflate(R.menu.activity_main, menu);
	    return true;
    }
    /**
     * Event 'onOptionsItemSelected' when user select item from option menu.
     */
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
	        case R.id.menu_new:
	        	Intent intent = new Intent(this, CFPActivity.class);
	        	intent.putExtra("callPhoto", true);
	            startActivity(intent);
	        	return true;
	        case R.id.menu_back:
	        	moveTaskToBack(true);
	        	return true;
	        case R.id.menu_settings:
	        	Intent intentSetting = new Intent(this, CFPSettingActivity.class);
	            startActivity(intentSetting);
	        	return true;           
	        case R.id.menu_about:
	        	Intent intentAbout = new Intent(this, CFPAboutActivity.class);
	            startActivity(intentAbout);
	            return true;
	        case R.id.menu_quit:
	        	finish();
	            System.exit(0);
	            return true;  
	        default:
	        	return super.onOptionsItemSelected(item);
        } 
    }
}
