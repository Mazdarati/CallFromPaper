package com.iitu.callfrompaper;
/**
 * Import Library
 */
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import android.content.Intent;
import android.content.res.AssetManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class CFPActivity extends CFPOptionMenuActivity {
	// Data from 'main' layout
	protected Button _buttonTakePhoto;
	protected Button _buttonAbout;
	protected Button _buttonQuit;
	protected String _path;
	protected boolean _taken;
	/**
	 * When start application
	 */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		String[] paths = new String[] { CFPSettingActivity.DATA_PATH, CFPSettingActivity.DATA_PATH + "tessdata/" };
		/**
		 * Create directory to 'tessdata'
		 */
		for (String path : paths) {
			File dir = new File(path);
			if (!dir.exists()) {
				if (!dir.mkdirs()) {
					Log.v(CFPSettingActivity.TAG, "ERROR: Creation of directory " + path + " on sdcard failed");
					return;
				} else {
					Log.v(CFPSettingActivity.TAG, "Created directory " + path + " on sdcard");
				}
			}
		}
		/**
		 * If doesn't consist files from 'traineddata'
		 */
		if (!(new File(CFPSettingActivity.DATA_PATH + "tessdata/" + CFPSettingActivity.lang + ".traineddata")).exists()) {
			try {
				AssetManager assetManager = getAssets();
				InputStream in = assetManager.open("tessdata/" + CFPSettingActivity.lang + ".traineddata");
				OutputStream out = new FileOutputStream(CFPSettingActivity.DATA_PATH
						+ "tessdata/" + CFPSettingActivity.lang + ".traineddata");
				// Transfer bytes from in to out
				byte[] buf = new byte[1024];
				int len;
				while ((len = in.read(buf)) > 0) {
					out.write(buf, 0, len);
				}
				in.close();
				out.close();
				Log.v(CFPSettingActivity.TAG, "Copied " + CFPSettingActivity.lang + " traineddata");
			} catch (IOException e) {
				Log.e(CFPSettingActivity.TAG, "Was unable to copy " + CFPSettingActivity.lang + " traineddata " + e.toString());
			}
		}
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		_buttonTakePhoto = (Button) findViewById(R.id.button_take_photo);
		_buttonTakePhoto.setOnClickListener(new ButtonClickHandler());
		_buttonAbout = (Button) findViewById(R.id.button_about);
		_buttonAbout.setOnClickListener(new ButtonClickHandler());
		_buttonQuit = (Button) findViewById(R.id.button_quit);
		_buttonQuit.setOnClickListener(new ButtonClickHandler());
		_path = CFPSettingActivity.DATA_PATH + "/last_photo.jpg";
		
		Intent intent = getIntent();
		if(intent.getBooleanExtra("callPhoto",false) == true) {
			startCameraActivity();
		}
	}
	
	/**
	 * Initialization camera activity
	 */
	protected void startCameraActivity() {
		File file = new File(_path);
		Uri outputFileUri = Uri.fromFile(file);
		final Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
		intent.putExtra(MediaStore.EXTRA_OUTPUT, outputFileUri);
		startActivityForResult(intent, 0);
	}
	/**
	 * Check activity status
	 */
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		Log.i(CFPSettingActivity.TAG, "resultCode: " + resultCode);
		if (resultCode == -1) {
			onPhotoTaken();
		} else {
			Log.v(CFPSettingActivity.TAG, "User cancelled");
		}
	}
	/**
	 * onSaveInstanceState
	 */
	@Override
	protected void onSaveInstanceState(Bundle outState) {
		outState.putBoolean(CFPSettingActivity.PHOTO_TAKEN, _taken);
	}
	/**
	 * onRestoreInstanceState
	 */
	@Override
	protected void onRestoreInstanceState(Bundle savedInstanceState) {
		Log.i(CFPSettingActivity.TAG, "onRestoreInstanceState()");
		if (savedInstanceState.getBoolean(CFPSettingActivity.PHOTO_TAKEN)) {
			onPhotoTaken();
		}
	}
	/**
	 * onPhotoTaken
	 */
	protected void onPhotoTaken() {
		_taken = true;
		Intent intentAbout = new Intent(this, CFPListActivity.class);
        startActivity(intentAbout);
	}
	/**
	 * When press some buttons.
	 */
	public class ButtonClickHandler implements View.OnClickListener {
		public void onClick(View view) {
			switch (view.getId()) {
			    case R.id.button_take_photo:
			    	startCameraActivity();
			    	break;
			    case R.id.button_about:
			    	Intent intentAbout2 = new Intent(CFPActivity.this, CFPAboutActivity.class);
			    	startActivity(intentAbout2);
			    	break;
			    case R.id.button_quit:
			    	finish();
		            System.exit(0);
			    	break;
			    default:
			    	break;
		    }
		}
	}
	
}