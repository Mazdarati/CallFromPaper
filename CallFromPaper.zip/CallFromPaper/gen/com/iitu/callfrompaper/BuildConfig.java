/** Automatically generated file. DO NOT MODIFY */
package com.iitu.callfrompaper;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}